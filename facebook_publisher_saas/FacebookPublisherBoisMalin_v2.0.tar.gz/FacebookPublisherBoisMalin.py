"""
Facebook Publisher Bois Malin - Main Application

This is the main application file for the Facebook Publisher Bois Malin tool.
It provides a Tkinter-based GUI for managing Facebook pages, posts, and ads.

Author: Manus AI
Date: June 19, 2025
"""

import tkinter as tk
from tkinter import ttk, filedialog, messagebox, simpledialog
import json
import os
from datetime import datetime, timedelta

from facebook_api import FacebookAPI, FacebookAPIError
from models.page import Page
from models.post import Post
from models.ad import AdCreative, Campaign, AdSet, Ad, BoostedPost
from utils import config, scheduler, logger

# Initialize logger
log = logger.get_logger("app")

class FacebookPublisherApp:
    """
    Main application class for Facebook Publisher Bois Malin
    """
    
    def __init__(self, root):
        """
        Initialize the main application window
        
        Args:
            root: Tkinter root window
        """
        self.root = root
        self.root.title("Facebook Publisher Bois Malin")
        self.root.geometry("1000x700")
        
        # Initialize Facebook API (will load from .env)
        try:
            self.fb_api = FacebookAPI()
        except ValueError as e:
            log.error(f"Failed to initialize Facebook API: {e}")
            messagebox.showerror("API Error", f"Failed to initialize Facebook API: {e}\nPlease check your .env file.")
            self.root.destroy()
            return
            
        # Initialize Post Scheduler
        self.post_scheduler = scheduler.PostScheduler(self.fb_api)
        self.post_scheduler.start(on_post_published=self._handle_post_published)
        
        # Load initial data
        self.pages_data = config.load_pages()
        self.scheduled_posts_data = config.load_scheduled_posts()
        self.boosted_ads_data = config.load_boosted_ads()
        
        self.pages: List[Page] = [Page.from_dict(p) for p in self.pages_data.get("pages", [])]
        self.scheduled_posts: List[Post] = [Post.from_dict(p) for p in self.scheduled_posts_data.get("posts", [])]
        self.boosted_ads: List[BoostedPost] = [BoostedPost.from_dict(ad) for ad in self.boosted_ads_data.get("boosted_posts", [])]
        
        # UI Setup
        self._create_widgets()
        self._load_initial_ui_data()
        
        log.info("FacebookPublisherApp initialized")

    def _handle_post_published(self, post: Post):
        """Callback when a scheduled post is published"""
        log.info(f"Scheduled post {post.post_id} published successfully.")
        messagebox.showinfo("Post Published", f"Scheduled post for page(s) {', '.join(post.page_ids)} has been published.")
        # Refresh UI if needed (e.g., update scheduled posts list)
        self._refresh_scheduled_posts_tab()

    def _create_widgets(self):
        """Create all UI widgets"""
        self.notebook = ttk.Notebook(self.root)
        
        # Create tabs
        self.tab_publication = ttk.Frame(self.notebook)
        self.tab_programmation = ttk.Frame(self.notebook)
        self.tab_publicites = ttk.Frame(self.notebook)
        self.tab_statistiques = ttk.Frame(self.notebook)
        self.tab_parametres = ttk.Frame(self.notebook)
        self.tab_a_propos = ttk.Frame(self.notebook)
        
        self.notebook.add(self.tab_publication, text="Publication")
        self.notebook.add(self.tab_programmation, text="Programmation")
        self.notebook.add(self.tab_publicites, text="Publicités")
        self.notebook.add(self.tab_statistiques, text="Statistiques")
        self.notebook.add(self.tab_parametres, text="Paramètres")
        self.notebook.add(self.tab_a_propos, text="À Propos")
        
        self.notebook.pack(expand=True, fill="both")
        
        # Populate tabs
        self._create_publication_tab()
        self._create_programmation_tab()
        self._create_publicites_tab()
        self._create_statistiques_tab()
        self._create_parametres_tab()
        self._create_a_propos_tab()

    def _load_initial_ui_data(self):
        """Load initial data into UI elements"""
        # Example: Load pages into a listbox in parameters tab
        self._refresh_pages_list_parametres()
        self._refresh_scheduled_posts_tab()
        # ... and other tabs

    # --- Publication Tab --- #
    def _create_publication_tab(self):
        """Create widgets for the Publication tab"""
        # Message entry
        ttk.Label(self.tab_publication, text="Message:").grid(row=0, column=0, padx=5, pady=5, sticky="w")
        self.publication_message_text = tk.Text(self.tab_publication, height=10, width=80)
        self.publication_message_text.grid(row=1, column=0, columnspan=3, padx=5, pady=5, sticky="nsew")
        
        # Link entry
        ttk.Label(self.tab_publication, text="Lien (optionnel):").grid(row=2, column=0, padx=5, pady=5, sticky="w")
        self.publication_link_entry = ttk.Entry(self.tab_publication, width=80)
        self.publication_link_entry.grid(row=2, column=1, columnspan=2, padx=5, pady=5, sticky="ew")
        
        # Media selection
        ttk.Label(self.tab_publication, text="Média:").grid(row=3, column=0, padx=5, pady=5, sticky="w")
        self.publication_media_path_var = tk.StringVar()
        ttk.Entry(self.tab_publication, textvariable=self.publication_media_path_var, width=60, state="readonly").grid(row=3, column=1, padx=5, pady=5, sticky="ew")
        ttk.Button(self.tab_publication, text="Ajouter une image", command=self._select_image_publication).grid(row=3, column=2, padx=5, pady=5)
        # TODO: Add video support if needed
        
        # Page selection
        ttk.Label(self.tab_publication, text="Pages:").grid(row=4, column=0, padx=5, pady=5, sticky="nw")
        self.publication_pages_listbox = tk.Listbox(self.tab_publication, selectmode=tk.MULTIPLE, height=10, exportselection=False)
        self.publication_pages_listbox.grid(row=4, column=1, columnspan=2, padx=5, pady=5, sticky="nsew")
        # Populate with pages from self.pages
        for page in self.pages:
            self.publication_pages_listbox.insert(tk.END, page.name)
            
        # Publish button
        ttk.Button(self.tab_publication, text="Publier maintenant", command=self._publish_now).grid(row=5, column=1, padx=5, pady=10)
        ttk.Button(self.tab_publication, text="Programmer...", command=self._open_schedule_dialog).grid(row=5, column=2, padx=5, pady=10)
        
        # Configure row/column weights for resizing
        self.tab_publication.grid_rowconfigure(1, weight=1)
        self.tab_publication.grid_rowconfigure(4, weight=1)
        self.tab_publication.grid_columnconfigure(1, weight=1)

    def _select_image_publication(self):
        """Open file dialog to select an image for publication"""
        filepath = filedialog.askopenfilename(
            title="Sélectionner une image",
            filetypes=(("Images JPEG", "*.jpg *.jpeg"), ("Images PNG", "*.png"), ("Tous les fichiers", "*.*"))
        )
        if filepath:
            self.publication_media_path_var.set(filepath)

    def _publish_now(self):
        """Handle immediate post publication"""
        message = self.publication_message_text.get("1.0", tk.END).strip()
        link = self.publication_link_entry.get().strip()
        media_path = self.publication_media_path_var.get().strip()
        selected_indices = self.publication_pages_listbox.curselection()
        
        if not message and not media_path:
            messagebox.showerror("Erreur", "Le message ou un média est requis.")
            return
            
        if not selected_indices:
            messagebox.showerror("Erreur", "Veuillez sélectionner au moins une page.")
            return
            
        selected_pages = [self.pages[i] for i in selected_indices]
        
        try:
            for page in selected_pages:
                page_token = page.access_token
                if not page_token:
                    # Attempt to get from main token if page token is missing (should be rare)
                    page_token = self.fb_api.access_token 
                    log.warning(f"Using system user token for page {page.id} as page-specific token is missing.")
                
                if media_path:
                    # Upload photo first
                    photo_response = self.fb_api.upload_photo(page.id, media_path, caption=message, published=False, page_access_token=page_token)
                    photo_id = photo_response.get("id")
                    if not photo_id:
                        raise FacebookAPIError("Échec de l'upload de la photo.")
                    # Publish post with attached photo
                    post_response = self.fb_api.publish_post_with_photos(page.id, message, [photo_id], page_access_token=page_token)
                else:
                    # Publish text/link post
                    post_response = self.fb_api.publish_post(page.id, message, link, page_access_token=page_token)
                
                post_id = post_response.get("id")
                log.info(f"Post {post_id} published to page {page.id} ({page.name})")
                # TODO: Offer to open post in browser
                # TODO: Add to a "recent posts" list for boosting
                
            messagebox.showinfo("Succès", "Publication effectuée avec succès sur les pages sélectionnées.")
            # Clear fields
            self.publication_message_text.delete("1.0", tk.END)
            self.publication_link_entry.delete(0, tk.END)
            self.publication_media_path_var.set("")
            
        except FacebookAPIError as e:
            log.error(f"API Error during publication: {e}")
            messagebox.showerror("Erreur API", f"Erreur lors de la publication : {e.message}")
        except Exception as e:
            log.error(f"Unexpected error during publication: {e}")
            messagebox.showerror("Erreur Inattendue", f"Une erreur inattendue s'est produite : {e}")

    def _open_schedule_dialog(self):
        """Open dialog to schedule a post"""
        message = self.publication_message_text.get("1.0", tk.END).strip()
        link = self.publication_link_entry.get().strip()
        media_path = self.publication_media_path_var.get().strip()
        selected_indices = self.publication_pages_listbox.curselection()

        if not message and not media_path:
            messagebox.showerror("Erreur", "Le message ou un média est requis pour programmer.")
            return

        if not selected_indices:
            messagebox.showerror("Erreur", "Veuillez sélectionner au moins une page pour programmer.")
            return

        selected_page_ids = [self.pages[i].id for i in selected_indices]

        # Simple dialog for date and time
        # In a real app, use a calendar widget
        schedule_str = simpledialog.askstring("Programmer la publication", 
                                              "Entrez la date et l'heure (YYYY-MM-DD HH:MM):")
        if not schedule_str:
            return

        try:
            scheduled_time = datetime.strptime(schedule_str, "%Y-%m-%d %H:%M")
            if scheduled_time <= datetime.now():
                messagebox.showerror("Erreur", "La date de programmation doit être dans le futur.")
                return

            new_post = Post(
                message=message,
                page_ids=selected_page_ids,
                link=link if link else None,
                image_paths=[media_path] if media_path else [],
                scheduled_time=scheduled_time
            )
            
            if self.post_scheduler.add_scheduled_post(new_post):
                messagebox.showinfo("Succès", f"Publication programmée pour {scheduled_time.strftime('%Y-%m-%d %H:%M')}.")
                self._refresh_scheduled_posts_tab()
                # Clear fields
                self.publication_message_text.delete("1.0", tk.END)
                self.publication_link_entry.delete(0, tk.END)
                self.publication_media_path_var.set("")
            else:
                messagebox.showerror("Erreur", "Échec de la programmation de la publication.")

        except ValueError:
            messagebox.showerror("Erreur de Format", "Format de date invalide. Utilisez YYYY-MM-DD HH:MM.")
        except Exception as e:
            log.error(f"Error scheduling post: {e}")
            messagebox.showerror("Erreur Inattendue", f"Erreur lors de la programmation : {e}")

    # --- Programmation Tab --- #
    def _create_programmation_tab(self):
        """Create widgets for the Programmation tab"""
        ttk.Label(self.tab_programmation, text="Publications programmées:").pack(padx=5, pady=5, anchor="w")
        
        self.programmation_tree = ttk.Treeview(self.tab_programmation, 
                                               columns=("message", "pages", "time", "status"), 
                                               show="headings")
        self.programmation_tree.heading("message", text="Message")
        self.programmation_tree.heading("pages", text="Pages")
        self.programmation_tree.heading("time", text="Heure programmée")
        self.programmation_tree.heading("status", text="Statut")
        self.programmation_tree.pack(expand=True, fill="both", padx=5, pady=5)
        
        ttk.Button(self.tab_programmation, text="Supprimer la sélection", command=self._delete_scheduled_post).pack(pady=5)
        ttk.Button(self.tab_programmation, text="Actualiser", command=self._refresh_scheduled_posts_tab).pack(pady=5)

    def _refresh_scheduled_posts_tab(self):
        """Refresh the list of scheduled posts in the UI"""
        # Clear existing items
        for item in self.programmation_tree.get_children():
            self.programmation_tree.delete(item)
            
        # Load posts from scheduler
        self.scheduled_posts = self.post_scheduler.get_scheduled_posts()
        for i, post in enumerate(self.scheduled_posts):
            status = "Publié" if post.published else ("En attente" if post.scheduled_time else "Erreur")
            if post.scheduled_time and not post.published and post.scheduled_time < datetime.now():
                status = "En retard"
            
            self.programmation_tree.insert("", tk.END, iid=str(i), values=(
                post.message[:50] + "..." if len(post.message) > 50 else post.message,
                ", ".join(post.page_ids),
                post.scheduled_time.strftime("%Y-%m-%d %H:%M") if post.scheduled_time else "N/A",
                status
            ))

    def _delete_scheduled_post(self):
        """Delete the selected scheduled post"""
        selected_item = self.programmation_tree.focus()
        if not selected_item:
            messagebox.showwarning("Aucune sélection", "Veuillez sélectionner une publication à supprimer.")
            return

        if messagebox.askyesno("Confirmer la suppression", "Êtes-vous sûr de vouloir supprimer cette publication programmée ?"):
            try:
                index = int(selected_item) # Assuming iid is the index
                if self.post_scheduler.remove_scheduled_post(index):
                    messagebox.showinfo("Succès", "Publication programmée supprimée.")
                    self._refresh_scheduled_posts_tab()
                else:
                    messagebox.showerror("Erreur", "Impossible de supprimer la publication programmée.")
            except ValueError:
                 messagebox.showerror("Erreur", "Sélection invalide pour la suppression.")
            except Exception as e:
                log.error(f"Error deleting scheduled post: {e}")
                messagebox.showerror("Erreur Inattendue", f"Erreur lors de la suppression : {e}")

    # --- Publicités Tab --- #
    def _create_publicites_tab(self):
        """Create widgets for the Publicités tab"""
        ttk.Label(self.tab_publicites, text="Gestion des publicités (Boost Post & Campagnes)").pack(padx=10, pady=10)
        # TODO: Implement Ad Management UI as per user prompt
        # - Ad Account Selector
        # - Page Selector
        # - Objective, Budget, Dates
        # - Targeting block
        # - Creative preview
        # - Buttons for create_campaign, create_adset, etc.
        # - List of existing ads/campaigns with status

    # --- Statistiques Tab --- #
    def _create_statistiques_tab(self):
        """Create widgets for the Statistiques tab"""
        ttk.Label(self.tab_statistiques, text="Statistiques des pages et publications").pack(padx=10, pady=10)
        # TODO: Implement Statistics UI
        # - Page selector
        # - Date range selector
        # - Display for page_impressions, page_engaged_users
        # - Post selector / list
        # - Display for post_impressions, post_engaged_users, post_reactions

    # --- Paramètres Tab --- #
    def _create_parametres_tab(self):
        """Create widgets for the Paramètres tab"""
        param_frame = ttk.LabelFrame(self.tab_parametres, text="Configuration Facebook")
        param_frame.pack(padx=10, pady=10, fill="x")

        # Token Management
        ttk.Label(param_frame, text="Token d'accès système actuel:").grid(row=0, column=0, padx=5, pady=5, sticky="w")
        self.system_token_var = tk.StringVar(value=self.fb_api.access_token if self.fb_api.access_token else "Non défini")
        ttk.Entry(param_frame, textvariable=self.system_token_var, width=70, state="readonly").grid(row=0, column=1, padx=5, pady=5, sticky="ew")
        
        ttk.Label(param_frame, text="Nouveau token système:").grid(row=1, column=0, padx=5, pady=5, sticky="w")
        self.new_system_token_entry = ttk.Entry(param_frame, width=70)
        self.new_system_token_entry.grid(row=1, column=1, padx=5, pady=5, sticky="ew")
        ttk.Button(param_frame, text="Mettre à jour token système", command=self._update_system_token).grid(row=1, column=2, padx=5, pady=5)

        ttk.Button(param_frame, text="Échanger token court terme", command=self._exchange_token).grid(row=2, column=1, padx=5, pady=5, sticky="w")
        ttk.Button(param_frame, text="Vérifier validité token système", command=self._debug_system_token).grid(row=2, column=2, padx=5, pady=5, sticky="w")
        self.token_expiry_label = ttk.Label(param_frame, text="Expiration du token: N/A")
        self.token_expiry_label.grid(row=3, column=1, columnspan=2, padx=5, pady=5, sticky="w")

        # Page Management
        pages_frame = ttk.LabelFrame(self.tab_parametres, text="Gestion des Pages")
        pages_frame.pack(padx=10, pady=10, fill="both", expand=True)
        
        ttk.Button(pages_frame, text="Actualiser la liste des pages Facebook", command=self._refresh_facebook_pages).pack(pady=5)
        self.parametres_pages_listbox = tk.Listbox(pages_frame, height=15, width=80)
        self.parametres_pages_listbox.pack(padx=5, pady=5, fill="both", expand=True)
        # TODO: Display page ID and page-specific token status

    def _update_system_token(self):
        """Update the system user access token"""
        new_token = self.new_system_token_entry.get().strip()
        if not new_token:
            messagebox.showerror("Erreur", "Veuillez entrer un nouveau token.")
            return
        
        # Update in fb_api instance
        self.fb_api.access_token = new_token
        # Update display
        self.system_token_var.set(new_token)
        # Save to .env (This is tricky, as .env is usually not modified by the app itself)
        # For now, this change is only for the current session.
        # A more robust solution would involve a config file or secure storage.
        log.info("System token updated for current session.")
        messagebox.showinfo("Token Mis à Jour", "Le token système a été mis à jour pour la session actuelle.")
        self._debug_system_token() # Check new token

    def _exchange_token(self):
        """Exchange a short-lived token for a long-lived one"""
        short_token = simpledialog.askstring("Échanger Token", "Entrez le token court terme:")
        if not short_token:
            return
        try:
            response = self.fb_api.exchange_token(short_token)
            long_token = response.get("access_token")
            if long_token:
                self.new_system_token_entry.delete(0, tk.END)
                self.new_system_token_entry.insert(0, long_token)
                messagebox.showinfo("Succès", f"Token long terme obtenu: {long_token[:30]}...")
                self._update_system_token() # Update with the new long-lived token
            else:
                messagebox.showerror("Erreur", f"Échec de l'échange du token: {response}")
        except FacebookAPIError as e:
            log.error(f"API Error during token exchange: {e}")
            messagebox.showerror("Erreur API", f"Erreur lors de l'échange du token : {e.message}")
        except Exception as e:
            log.error(f"Unexpected error during token exchange: {e}")
            messagebox.showerror("Erreur Inattendue", f"Une erreur inattendue s'est produite : {e}")

    def _debug_system_token(self):
        """Debug the current system token and display expiry"""
        if not self.fb_api.access_token:
            self.token_expiry_label.config(text="Expiration du token: Aucun token système défini.")
            return
        try:
            response = self.fb_api.debug_token(self.fb_api.access_token)
            data = response.get("data", {})
            if data.get("is_valid"):
                expires_at = data.get("expires_at")
                if expires_at and expires_at != 0:
                    expiry_dt = datetime.fromtimestamp(expires_at)
                    self.token_expiry_label.config(text=f"Expiration du token: {expiry_dt.strftime('%Y-%m-%d %H:%M:%S')}")
                    # Check for expiry warning
                    if expiry_dt - datetime.now() < timedelta(days=7):
                        messagebox.showwarning("Expiration Proche", "Votre token Facebook va expirer dans moins de 7 jours!")
                else:
                    self.token_expiry_label.config(text="Expiration du token: N'expire pas (ou inconnu).")
            else:
                error_msg = data.get("error", {}).get("message", "Token invalide.")
                self.token_expiry_label.config(text=f"Expiration du token: {error_msg}")
                messagebox.showerror("Token Invalide", error_msg)
        except FacebookAPIError as e:
            log.error(f"API Error during token debug: {e}")
            self.token_expiry_label.config(text=f"Expiration du token: Erreur API - {e.message}")
            messagebox.showerror("Erreur API", f"Erreur lors de la vérification du token : {e.message}")
        except Exception as e:
            log.error(f"Unexpected error during token debug: {e}")
            self.token_expiry_label.config(text=f"Expiration du token: Erreur inattendue - {e}")
            messagebox.showerror("Erreur Inattendue", f"Une erreur inattendue s'est produite : {e}")

    def _refresh_facebook_pages(self):
        """Refresh the list of Facebook pages from the API"""
        try:
            pages_response = self.fb_api.get_user_pages()
            self.pages = [Page.from_api_response(p) for p in pages_response]
            
            # Save pages to JSON
            pages_to_save = {"pages": [p.to_dict() for p in self.pages]}
            config.save_pages(pages_to_save)
            
            # Update UI elements
            self._refresh_pages_list_parametres()
            self._refresh_pages_list_publication()
            
            messagebox.showinfo("Succès", f"{len(self.pages)} pages Facebook récupérées et sauvegardées.")
        except FacebookAPIError as e:
            log.error(f"API Error refreshing pages: {e}")
            messagebox.showerror("Erreur API", f"Erreur lors de la récupération des pages : {e.message}")
        except Exception as e:
            log.error(f"Unexpected error refreshing pages: {e}")
            messagebox.showerror("Erreur Inattendue", f"Une erreur inattendue s'est produite : {e}")

    def _refresh_pages_list_parametres(self):
        """Refresh the pages list in the Paramètres tab"""
        self.parametres_pages_listbox.delete(0, tk.END)
        for page in self.pages:
            self.parametres_pages_listbox.insert(tk.END, f"{page.name} (ID: {page.id})")

    def _refresh_pages_list_publication(self):
        """Refresh the pages list in the Publication tab"""
        self.publication_pages_listbox.delete(0, tk.END)
        for page in self.pages:
            self.publication_pages_listbox.insert(tk.END, page.name)

    # --- À Propos Tab --- #
    def _create_a_propos_tab(self):
        """Create widgets for the À Propos tab"""
        ttk.Label(self.tab_a_propos, text="Facebook Publisher Bois Malin", font=("Helvetica", 16, "bold")).pack(pady=10)
        ttk.Label(self.tab_a_propos, text="Version 2.0 (API Intégrée)").pack(pady=5)
        ttk.Label(self.tab_a_propos, text="Développé par Manus AI pour Nicolas Pycik").pack(pady=5)
        ttk.Label(self.tab_a_propos, text="© 2025").pack(pady=5)
        # TODO: Add more details from README.md or link to it

    def on_closing(self):
        """Handle window closing event"""
        log.info("Closing application...")
        if self.post_scheduler:
            self.post_scheduler.stop()
        self.root.destroy()


if __name__ == "__main__":
    # This file should be run via main.py for proper imports
    print("Please run the application using: python main.py")
    print("This ensures proper module imports and initialization.")

