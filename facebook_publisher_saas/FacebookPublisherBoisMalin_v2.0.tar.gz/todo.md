# Facebook Publisher Bois Malin - Todo List

## Phase 2: Développer l'intégration API Facebook et les nouvelles fonctionnalités

### Corrections structurelles
- [x] Corriger les imports relatifs dans FacebookPublisherBoisMalin.py
- [x] Créer un fichier __init__.py pour faire du dossier un package Python
- [x] Créer un fichier .env.example avec les variables d'environnement nécessaires
- [x] Corriger les imports dans tous les modules

### Intégration API Facebook réelle
- [x] Finaliser le wrapper facebook_api.py avec toutes les méthodes nécessaires
- [x] Implémenter la récupération réelle des pages Facebook
- [x] Implémenter la publication réelle de posts (texte, images, liens)
- [x] Implémenter la planification avec thread scheduler
- [ ] Ajouter la fonctionnalité de boost post
- [ ] Créer l'onglet Publicités avec création de campagnes

### Fonctionnalités avancées
- [ ] Système de statistiques réelles via l'API Insights
- [ ] Gestion des tokens long terme
- [ ] Interface pour le ciblage publicitaire
- [ ] Gestion des budgets et dates de campagne

### Tests et validation
- [x] Corriger les tests unitaires
- [x] Tester la publication réelle
- [x] Tester la planification
- [ ] Tester les fonctionnalités publicitaires

